export interface Component {
  id: string;
  name: string;
  type: string;
  value: string;
  package: string;
  position: { x: number; y: number; z: number };
  rotation: number;
  net?: string;
}

export interface ChangeCard {
  id: string;
  intent: string;
  description: string;
  affectedItems: string[];
  status: "applied" | "error" | "pending";
  timestamp: Date;
}

export type FidelityMode = "Concept" | "Draft" | "Production";
export type ViewMode = "Layout" | "Schematic" | "3D" | "BOM";

export interface AppState {
  components: Component[];
  history: ChangeCard[];
  fidelity: FidelityMode;
  view: ViewMode;
  selectedId: string | null;
}

export interface AgentTask {
  id: string;
  label: string;
  status: "pending" | "running" | "completed" | "error";
  details?: string;
  timing?: number;
  isExpanded?: boolean;
}

export interface AgentTool {
  id: string;
  name: string;
  args: Record<string, any>;
  result?: any;
  status: "running" | "completed" | "error";
  error?: string;
  timestamp: Date;
  timing?: number;
}

export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  // Task-based UI fields
  openingNote?: string;
  tasks?: AgentTask[];
  tools?: AgentTool[];
  closingNote?: string;
  previewData?: {
    changeId: string;
    description: string;
    affectedItems: string[];
  };
}

export type AppMode = "LANDING" | "CHAT_PREVIEW" | "SPLIT_VIEW";
